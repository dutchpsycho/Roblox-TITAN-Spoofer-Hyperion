#ifndef MAC_HPP
#define MAC_HPP

#include <string>
#include <vector>

void spoofMac();
std::wstring stringToWstring(const std::string& s);
std::string wstringToString(const std::wstring& ws);

#endif