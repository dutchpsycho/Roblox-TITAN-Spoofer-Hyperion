#ifndef SIGFUCK_HPP
#define SIGFUCK_HPP

#include <windows.h>
#include <string>

void SigFucker();
void WindowName();

#endif