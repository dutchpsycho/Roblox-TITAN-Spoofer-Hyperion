#ifndef RESOURCE_H
#define RESOURCE_H

#define IDR_SQLITE_DLL 101

#endif